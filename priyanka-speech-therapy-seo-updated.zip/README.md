# Priyanka Speech & Language Therapy — Website

Static, responsive GitHub Pages website for Priyanka Sharma, Senior Speech & Language Therapist (ASLP).

## Update highlights
- Solid ivory navigation background, including while scrolling.
- Mobile navigation activates at viewport widths of 1024px and below.
- Added a detailed, responsive fluency and speech-practice section with the requested 19 techniques, grouped by theme.
- Includes a note that strategies should be selected with a qualified speech-language therapist and may not suit every person.
- Uses inline SVG icons and CSS styling for the new section.

## Publish
Upload the contents of this ZIP to the root of the existing GitHub Pages repository. `index.html` is the default page.


Latest update: content container expanded to 1300px; mobile/off-canvas navigation is used through 1300px to prevent desktop menu wrapping; brand subtitle reduced to 7px; contact email updated to piyanka444@gmail.com; SEO meta tags and JSON-LD structured data (Person, ProfessionalService, WebSite, WebPage, FAQPage) added.
